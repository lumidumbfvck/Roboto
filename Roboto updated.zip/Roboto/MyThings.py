import socket
from pygame import Vector2
import pygame
import typing
import smtplib
import re


def font_from_height(height: int, font_name_or_file: str, bold: bool, italic: bool):
    font = None
    for i in range(0, 999):
        if "." in font_name_or_file:
            font = pygame.font.Font(font_name_or_file, i)
        else:
            font = pygame.font.SysFont(font_name_or_file, i, bold, italic)
        if font.get_height() == height:
            break
    return font


def check_email(email: str):
    if re.match(".+@.{3,}\.((com)|(ee)|(ut))", email):
        return True
    return False


def send_email(sender_email, sender_password, receiver_email, msg_subject, msg_body):
    with smtplib.SMTP(socket.gethostbyname(socket.gethostname()), 5555) as server:
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(sender_email, sender_password)
        msg = f"Subject: {msg_subject}\n\n{msg_body}"
        server.sendmail(sender_email, receiver_email, msg)


class PygameButton:
    def __init__(self, pos: Vector2, width: int, height: int, text: str, manager=None, font: pygame.font.Font = None,
                 background_img_or_color: typing.Union[tuple, list, pygame.Surface] = (127, 127, 127),
                 text_img_or_color: typing.Union[list, tuple, pygame.Surface] = (0, 0, 0)):
        try:
            a = manager.draw
            a = manager.update
            a = manager.handle_events
            manager.add_element(self)
            self.manager = manager
        except AttributeError:
            pass
        self.img = None
        self.clicked = False
        if font is None:
            font = font_from_height(int(height / 3 * 2), "Franklin Gothic", True, False)
        self.rect = pygame.Rect(pos, (max(width, font.size(text)[0] + 20), max(height, font.size(text)[1] + 10)))
        if isinstance(background_img_or_color, (tuple, list)):
            self.img = pygame.Surface((self.rect.width, self.rect.height))
            # pygame.draw.rect(self.img, background_img_or_color,
            #                  pygame.Rect((self.rect.left, self.rect.top + self.rect.height // 6), (self.rect.width, self.rect.height - self.rect.height // 6 * 2)))
            # pygame.draw.rect(self.img, background_img_or_color,
            #                  pygame.Rect((self.rect.left + self.rect.height // 6, self.rect.top), (self.rect.width - self.rect.height // 6 * 2, self.rect.height)))
            # pygame.draw.circle(self.img, background_img_or_color, (self.rect.left + self.rect.height // 6, self.rect.top + self.rect.height // 6), self.rect.height // 6)
            # pygame.draw.circle(self.img, background_img_or_color, (self.rect.right - self.rect.height // 6, self.rect.top + self.rect.height // 6), self.rect.height // 6)
            # pygame.draw.circle(self.img, background_img_or_color, (self.rect.left + self.rect.height // 6, self.rect.bottom - self.rect.height // 6), self.rect.height // 6)
            # pygame.draw.circle(self.img, background_img_or_color, (self.rect.right - self.rect.height // 6, self.rect.bottom - self.rect.height // 6), self.rect.height // 6)
            rect = pygame.Rect((0, 0), font.size(text))
            rect.center = self.rect.center
            if isinstance(text_img_or_color, (tuple, list)):
                self.img.blit(font.render(text, True, text_img_or_color),
                              Vector2(rect.topleft) - Vector2(self.rect.topleft))
            else:
                self.img.blit(text_img_or_color, Vector2(rect.topleft) - Vector2(self.rect.topleft))
        else:
            self.img = pygame.transform.scale(background_img_or_color, (self.rect.width, self.rect.height))
            rect = pygame.Rect((0, 0), font.size(text))
            rect.center = self.rect.center
            if isinstance(text_img_or_color, (tuple, list)):
                self.img.blit(font.render(text, True, text_img_or_color),
                              Vector2(rect.topleft) - Vector2(self.rect.topleft))
            else:
                self.img.blit(text_img_or_color, Vector2(rect.topleft) - Vector2(self.rect.topleft))

    def draw(self, window: pygame.Surface):
        window.blit(self.img, self.rect)

    def handle_event(self, event: pygame.event.Event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and self.rect.collidepoint(event.pos):
            self.clicked = True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.clicked = False

    def get_pressed(self):
        return self.clicked

    def remove_from_manager(self):
        try:
            self.manager.remove_element(self)
        except AttributeError:
            return


class PygameInput:
    def __init__(self, position: pygame.math.Vector2, width: int, height: int, fps: int, manager=None,
                 only_numeric=False, value: str = "", placeholder: str = "", max_length: int = -1,
                 is_password: bool = False):
        self.is_password = is_password
        self.placeholder = placeholder
        try:
            a = manager.draw
            a = manager.update
            a = manager.handle_events
            manager.add_element(self)
            self.manager = manager
        except AttributeError:
            pass
        self.activated = False
        self.position = position
        self.size = (width, height)
        self.rect = pygame.Rect(position.xy, (width, height))
        self.fps = fps // 2
        self.countdown = fps // 2
        self.max_length = max_length
        self.value = value
        self.draw_line = True
        self.font = font_from_height(height // 3 * 2, "Franklin Gothic", True, False)
        self.text_rect = pygame.Rect((self.rect.left, self.rect.top + height // 3),
                                     self.font.render(self.value, False, (0, 0, 0)).get_size())
        self.only_numeric = only_numeric
        if max_length == 0:
            raise ValueError("Invalid maximum length!")

    def process_events(self, event: pygame.event.Event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.activated = True
            else:
                self.activated = False
                if not self.value and self.only_numeric:
                    self.value = "0"
        if event.type == pygame.KEYDOWN and self.activated:
            if event.key == pygame.K_RETURN:
                self.activated = False
                return
            if event.key == pygame.K_BACKSPACE or event.key == pygame.K_DELETE:
                self.value = self.value[:-1]
            elif (len(self.value) < self.max_length if self.max_length > 0 else True) and \
                    (event.unicode.isnumeric() or (event.unicode == "-" and not len(self.value)) if
                    self.only_numeric else True):
                self.value += event.unicode

    def update(self):
        self.rect.width = max(self.size[0], self.text_rect.width + 30)
        self.text_rect = pygame.Rect((self.rect.left, self.rect.top + 10),
                                     self.font.render(self.value if not self.is_password else "*" * len(self.value),
                                                      False, (0, 0, 0)).get_size())
        if self.activated:
            if not self.countdown:
                if not self.draw_line:
                    self.draw_line = True
                else:
                    self.draw_line = False
                self.countdown = self.fps

            self.countdown -= 1
        else:
            self.countdown = self.fps
            self.draw_line = False
            if not self.value and self.only_numeric:
                self.value = "0"

    def draw(self, window: pygame.Surface):
        color = (127, 127, 127, 127) if not self.activated else (0, 0, 0)
        pygame.draw.line(window, color, (self.rect.left, self.text_rect.bottom),
                         (self.rect.right, self.text_rect.bottom))
        window.blit(self.font.render(self.value if not self.is_password else "*" * len(self.value), True, (0, 0, 0)),
                    self.text_rect)
        if not self.value and not (self.activated and False):
            window.blit(self.font.render(self.placeholder, True, (127, 127, 127, 127)),
                        (self.rect.left, self.text_rect.centery - self.font.get_height() // 2))
        if self.draw_line:
            pygame.draw.line(window, (0, 0, 0), (self.text_rect.right + 1, self.text_rect.top),
                             (self.text_rect.right + 1, self.text_rect.bottom))

    def get_text(self):
        return self.value if not self.only_numeric or not self.value or self.value == "-" else int(self.value)

    def remove_from_manager(self):
        try:
            self.manager.remove_element(self)
        except AttributeError:
            return


class PygameSlider:
    def __init__(self, pos: Vector2, width: int, height: int, manager=None,
                 background_color_or_img: typing.Union[tuple, list, pygame.Surface] = (126, 126, 126),
                 slider_color_or_img: typing.Union[tuple, list, pygame.Surface] = (20, 20, 20), min_value: int = 0,
                 max_value: int = 100, show_value: bool = False):
        try:
            a = manager.draw
            a = manager.update
            a = manager.handle_events
            manager.add_element(self)
            self.manager = manager
        except AttributeError:
            pass
        self.img = None
        self.slider_img = None
        if isinstance(background_color_or_img, (list, tuple)):
            self.img = pygame.Surface((width, height))
            self.img.fill(background_color_or_img)
        else:
            self.img = pygame.transform.scale(background_color_or_img, (width, height))
        if isinstance(slider_color_or_img, (list, tuple)):
            self.slider_img = pygame.Surface((int(width / max_value * 10), height))
            self.slider_img.fill(slider_color_or_img)
        else:
            self.slider_img = pygame.transform.scale(background_color_or_img, (int(width / max_value * 10), height))
        self.rect = pygame.Rect(pos, (width, height))
        self.show_value = show_value
        self.range = (min_value, max_value)
        self.value = min_value
        self.slider_rect = self.slider_img.get_rect(centerx=self.rect.left + ((width // max_value) * self.value),
                                                    top=self.rect.top)
        self.dragging = False

    def draw(self, window: pygame.Surface):
        window.blit(self.img, self.rect)
        window.blit(self.slider_img, self.slider_rect)

    def handle_event(self, event: pygame.event.Event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not self.dragging and self.slider_rect.collidepoint(
                event.pos):
            self.dragging = True
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        if self.dragging:
            try:
                self.slider_rect.x = event.pos[0]
            except AttributeError:
                self.value = 0
                return
            self.value = 0

    def remove_from_manager(self):
        try:
            self.manager.remove_element(self)
        except AttributeError:
            return


class GUIManager:
    """
    A manager for pygame gui elements like PygameButton, PygameSlider and PygameInput.
    These classes can be used also without the GUIManager class, but then you need to call
    the draw() and the update() method yourself.

    """

    def __init__(self, window: pygame.Surface):
        self.__elements = []
        self.window = window

    def handle_events(self, event: pygame.event.Event):
        for element in self.__elements:
            if isinstance(element, (PygameButton, PygameSlider)):
                element.handle_event(event)
            else:
                element.process_events(event)

    def update(self):
        for element in self.__elements:
            if isinstance(element, PygameInput):
                element.update()

    def draw(self):
        for element in self.__elements:
            element.draw(self.window)

    @property
    def elements(self):
        return self.__elements

    def add_element(self, element):
        if isinstance(element, (PygameButton, PygameInput, PygameSlider)):
            self.__elements.append(element)

    def remove_element(self, element):
        if element in self.elements:
            self.__elements.remove(element)