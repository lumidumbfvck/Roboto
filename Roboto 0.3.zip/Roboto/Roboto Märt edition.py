import pygame
import random
#import typing
#from pygame import Vector2
#from MyThings import *
pygame.init()
#pygame ja juhuse mooduli käivitamine "Pancakes" (Eriku lunimisel)
ekraani_kõrgus = 1200
ekraani_laius = 2400
ekraan = pygame.display.set_mode([ekraani_laius, ekraani_kõrgus])
#ruutude suuruse ja arvu määaramine

TIITELLEHT = "skong"
MANG = "häda metamänguritele"
LOPULEHT = "Pancakes!"
#100% vajalik defineerimine

juhendi_tekst = [
    "Tere tulemast Roboto mängu!",
    "See mäng on loodud austuse ja loovuse vaimus.",
    "Me tunnustame mustanahaliste kogukondade panust",
    "kultuuri, muusika, tehnoloogia ja mängude arengusse.",
    "",
    "Sinu eesmärk:",
    "Seisa vastu korrumpeerunud süsteemile.",
    "Väldi rünnakuid ja kasuta nutikust, mitte viha.",
    "",
    "Liikumine: ← →",
    "Tulistamine: ↑",
    "",
    "Ühtsus. Austus. Vastupanu.",
    "Vajuta ÜLES, et alustada."
]


võidu_tekst = [ "VÕIT!",
    "",
    "See võit sümboliseerib vastupanu ebaõiglusele.",
    "Mängud on kõigi jaoks.",
    "Loovus ei tunne nahavärvi.",
    "",
    "Austus mustanahaliste kogukondadele",
    "ja kõigile, kes ehitavad paremat tulevikku."
              ]
#juhendi tekst + Märdi tehtud võidu tekst
kuulid = []
roboti_elud = 130000
roboti_laius = 2400
roboti_pikkus = 450
robot = pygame.Rect(0, 0, roboti_laius, roboti_pikkus)
roboti_kujutis = pygame.image.load("Robot.png")
roboti_kujutis = pygame.transform.scale(roboti_kujutis, (roboti_laius, roboti_pikkus))
#vastase ettevalmistus

mängija_suurus = 200
mängija_kiirus = 8
mängija_elud = 5
mängija = pygame.Rect(0, 0, 50, 50)
mängija.centerx = ekraani_laius // 2
mängija.bottom = ekraani_kõrgus - 200
mängija_kujutis = pygame.image.load("Urmas seisab.png")
mängija_kujutis = pygame.transform.scale(mängija_kujutis, (mängija_suurus, mängija_suurus))
mängija_laseb = pygame.image.load("Urmas crash out.png")
mängija_laseb = pygame.transform.scale(mängija_laseb, (mängija_suurus, mängija_suurus))
#mängija ettevalmistus
#algus_nupp = PygameButton(pygame.Vector2((ekraani_laius // 2, ekraani_kõrgus // 2)), 200, 200, "Alusta mangu", text_img_or_color=(255, 255, 255))

#akna tekitamine

ekraan = pygame.display.set_mode([ekraani_laius, ekraani_kõrgus])
#ekraani määramine
mäng_võidetud = False
mäng_kaotatud = False
mäng_käib = True
mängu_faas = TIITELLEHT
while mäng_käib:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            mäng_käib = False
        #algus_nupp.handle_event(e)
            #mängu normaalne kinnipanemine
    Klahvid = pygame.key.get_pressed()
    #tulevikus mängija juhtimise jaoks
    
    
    ekraan.fill((96, 96, 96))
    if mängu_faas == TIITELLEHT:
        if Klahvid[pygame.K_UP]:# or algus_nupp.get_pressed():
            mängu_faas = MANG
        font = pygame.font.Font(None, 50)
        for i, tekst in enumerate(juhendi_tekst):
            teksti_pind = font.render(tekst, True, (255, 255, 255))
            teksti_asukoht = (600,
                              300 + i * 40)
            ekraan.blit(teksti_pind, teksti_asukoht)
            #prindi juhendi tekst (kui mäng on parasjagu tiitellehe faasis)
        #algus_nupp.draw(ekraan)
    #  pygame.display.flip()
    #värskenda ekraan
    
    
    if mängu_faas == MANG:
        ekraan.blit(roboti_kujutis, robot)
        if Klahvid[pygame.K_LEFT]:
            mängija.x -= mängija_kiirus
        if Klahvid[pygame.K_RIGHT]:
            mängija.x += mängija_kiirus
    #mängija liikumine nooleklahvidega
        if mängija.left < 0:
            mängija.left = 0
        if mängija.right > ekraani_laius:
            mängija.right = ekraani_laius
    #mängija ekraani piiridesse panek
        if Klahvid[pygame.K_UP]:
            ekraan.blit(mängija_laseb, mängija)
            roboti_elud -= 80
        else:
            ekraan.blit(mängija_kujutis, mängija)
    #mängija laskmine
        if roboti_elud <= 0:
            mängu_faas = LOPULEHT
            mäng_võidetud = True
    #mängu võitmine
        if random.randint(0, 100) < 15:
            kuul = pygame.Rect(
                random.randint(0, ekraani_laius - 30),
                robot.bottom,
                30, 30
            )
            kuulid.append(kuul)
        for kuul in kuulid:
            kuul.y +=1
            pygame.draw.rect(ekraan, (255, 50, 50), kuul)
            if kuul.colliderect(mängija):
                mängija_elud -= 1
                kuulid.remove(kuul)
                if mängija_elud <= 0:
                    mäng_käib = False 
            elif kuul.top > ekraani_kõrgus:
                kuulid.remove(kuul)
    
    #vastase kuulid + mängu kaotamine + ekraani värskendus
    
    
    
    if mängu_faas == LOPULEHT:
        ekraan.fill((96, 96, 96))
        font = pygame.font.Font(None, 50)
        for i, tekst in enumerate(võidu_tekst):
            teksti_pind = font.render(tekst, True, (255, 255, 255))
            teksti_asukoht = (600,
                              300 + i * 40)
            ekraan.blit(teksti_pind, teksti_asukoht)
            # Lõpulehe väljastamine
    pygame.display.flip()
    #ekraani värskendamine
pygame.quit()
