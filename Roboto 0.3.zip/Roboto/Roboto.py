import pygame
import random
#pygame ja juhuse mooduli käivitamine

ekraani_kõrgus = 1200
ekraani_laius = 2400
ekraan = pygame.display.set_mode([ekraani_laius, ekraani_kõrgus])
#ruutude suuruse ja arvu määaramine

TIITELLEHT = "skong"
MANG = "häda metamänguritele"
#vajalik defineerimine

juhendi_tekst = [
        "Tere tulemast Roboto mängu!",
        "Proovi vältida roboti rünnakuid ja robotit vabadel hetkedel vastu tulistada.",
        "Edu!",
        "Vajuta ülemist nooleklahvi, et alustada."
]
#juhendi tekst
kuulid = []
roboti_elud = 10000
roboti_laius = 2400
roboti_pikkus = 800
robot = pygame.Rect(0, 0, roboti_laius, roboti_pikkus)
roboti_kujutis = pygame.image.load("evil wall of wires.png")
roboti_kujutis = pygame.transform.scale(roboti_kujutis, (roboti_laius, roboti_pikkus))
#vastase ettevalmistus

mängija_suurus = 200
mängija_kiirus = 10
mängija_elud = 3
mängija = pygame.Rect(ekraani_laius//2, ekraani_kõrgus - mängija_suurus*2, mängija_suurus, mängija_suurus)
mängija_kujutis = pygame.image.load("Urmas seisab.png")
mängija_kujutis = pygame.transform.scale(mängija_kujutis, (mängija_suurus, mängija_suurus))
mängija_laseb = pygame.image.load("Urmas crash out.png")
mängija_laseb = pygame.transform.scale(mängija_laseb, (mängija_suurus, mängija_suurus))
#mängija ettevalmistus

tulistamise_aeg = 0
tulistamise_kestus = 200
#tulistamise kiiruse kontroll

pygame.init()
#akna tekitamine

ekraan = pygame.display.set_mode([ekraani_laius, ekraani_kõrgus])
#ekraani määramine

mäng_käib = True
mängu_faas = TIITELLEHT
while mäng_käib:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            mäng_käib = False
            #mängu normaalne kinnipanemine
    Klahvid = pygame.key.get_pressed()
    #tulevikus controllide jaoks
    
    
    ekraan.fill((41, 41, 41))
    if mängu_faas == TIITELLEHT:
        if Klahvid[pygame.K_UP]:
            mängu_faas = MANG
        font = pygame.font.Font(None, 50)
        for i, tekst in enumerate(juhendi_tekst):
            teksti_pind = font.render(tekst, True, (255, 255, 255))
            teksti_asukoht = (600,
                              300 + i * 40)
            ekraan.blit(teksti_pind, teksti_asukoht)
            #prindi juhendi tekst (kui mäng on parasjagu tiitellehe faasis)
    
    pygame.display.flip()
    #värskenda ekraan
    
    
    if mängu_faas == MANG:
        ekraan.blit(roboti_kujutis, robot)
        if Klahvid[pygame.K_LEFT]:
            mängija.x -= mängija_kiirus
        if Klahvid[pygame.K_RIGHT]:
            mängija.x += mängija_kiirus
        
            
    #mängija liikumine ja laskmine nooleklahvidega
        if mängija.left < 0:
            mängija.left = 0
        if mängija.right > ekraani_laius:
            mängija.right = ekraani_laius
    #mängija ekraani piiridesse panek
        if Klahvid[pygame.K_UP]:
            ekraan.blit(mängija_laseb, mängija)
            roboti_elud -= 20
        else:
            ekraan.blit(mängija_kujutis, mängija)
        if roboti_elud < 0:
            mäng_käib = False
        
        
        
        
        
        if random.randint(0, 100) < 5:
            kuul = pygame.Rect(
                random.randint(0, ekraani_laius - 30),
                robot.bottom,
                30, 30
            )
            kuulid.append(kuul)
        for kuul in kuulid [:]:
            kuul.y += 10
            pygame.draw.rect(ekraan, (255, 50, 50), kuul)
            if kuul.colliderect(mängija):
                mängija_elud -= 1
                kuulid.remove(kuul)
                if mängija_elud <= 0:
                    mäng_käib = False 
            elif kuul.top > ekraani_kõrgus:
                kuulid.remove(kuul)
    pygame.display.flip()
    #mängija laskmine + värskendamine + roboti surma korral mängu kinni panemine   
pygame.quit()